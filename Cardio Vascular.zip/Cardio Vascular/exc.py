import streamlit as st

# Define exercise recommendations based on symptoms and fitness levels
def recommend_exercise(symptom, fitness_level):
    exercise_dict = {
        'shortness of breath': {
            'beginner': "Try gentle walking or swimming. Avoid any high-intensity activities.",
            'intermediate': "Consider cycling at a slow pace or light jogging.",
            'advanced': "Engage in low-intensity swimming or a light cardio routine."
        },
        'chest pain': {
            'beginner': "Please rest and consult a doctor. Avoid all physical activities for now.",
            'intermediate': "Consult a healthcare provider before attempting any exercises.",
            'advanced': "Consult a healthcare provider for further evaluation before considering exercise."
        },
        'fatigue': {
            'beginner': "Walk or cycle at a slow pace to build stamina gradually.",
            'intermediate': "Moderate cycling or walking will help build energy levels.",
            'advanced': "Try moderate to intense cycling or interval walking to improve stamina."
        },
        'dizziness': {
            'beginner': "Light stretching or yoga exercises are recommended.",
            'intermediate': "Gentle walking or stretching can help maintain balance.",
            'advanced': "Focus on low-intensity workouts like walking or gentle yoga."
        },
        'rapid heart rate': {
            'beginner': "Focus on walking at a slow pace or very light cycling.",
            'intermediate': "Moderate walking or cycling while monitoring your heart rate is ideal.",
            'advanced': "Low-intensity steady-state cardio like cycling or brisk walking is best."
        },
        'swelling in legs': {
            'beginner': "Gentle swimming or walking is helpful. Avoid prolonged standing.",
            'intermediate': "Moderate walking or water aerobics can help.",
            'advanced': "Low-impact exercises like cycling or swimming are ideal."
        },
        'no symptoms': {
            'beginner': "Start with brisk walking or light jogging.",
            'intermediate': "Running, cycling, or swimming at a moderate intensity is recommended.",
            'advanced': "Try interval training, HIIT, or long-distance cycling/running."
        }
    }
    
    # Get the recommendation for the selected symptom and fitness level
    return exercise_dict.get(symptom.lower(), {}).get(fitness_level.lower(), "No recommendation available for this combination.")

# App title
st.title("Cardiovascular Exercise Recommendation System")

# Symptom and fitness level input from the user
st.header("Enter your symptoms and fitness level:")

# Select symptom
symptoms = ['shortness of breath', 'chest pain', 'fatigue', 'dizziness', 'rapid heart rate', 'swelling in legs', 'no symptoms']
symptom = st.selectbox("Select a symptom", symptoms)

# Select fitness level
fitness_levels = ['beginner', 'intermediate', 'advanced']
fitness_level = st.selectbox("Select your fitness level", fitness_levels)

# Get exercise recommendation based on input
if symptom and fitness_level:
    recommendation = recommend_exercise(symptom, fitness_level)
    st.subheader("Recommended Exercise:")
    st.write(recommendation)



# Virtual Trainer with Video Demonstrations
def get_video_demo(exercise):
    # Map exercise to a demo video link
    video_links = {
        'walking': 'https://www.youtube.com/',
        'cycling': 'https://www.youtube.com/',
        'swimming': 'https://www.youtube.com/',
        'running': 'https://www.youtube.com/',
    }
    return video_links.get(exercise, '')

# Customizable Workout Plans based on user goals
def generate_workout_plan(goal):
    # Example goals and corresponding plans
    workout_plans = {
        'lose weight': {
            'Monday': '45 mins brisk walking',
            'Tuesday': '30 mins cycling, 15 mins bodyweight exercises',
            'Wednesday': 'Rest day',
            'Thursday': '45 mins jogging',
            'Friday': '30 mins swimming',
            'Saturday': 'Rest day',
            'Sunday': '30 mins running'
        },
        'increase stamina': {
            'Monday': '40 mins cycling',
            'Tuesday': 'Interval running (20 mins)',
            'Wednesday': 'Rest day',
            'Thursday': '45 mins brisk walking',
            'Friday': '40 mins swimming',
            'Saturday': 'Rest day',
            'Sunday': '1 hour jogging'
        },
        'maintain fitness': {
            'Monday': '30 mins swimming',
            'Tuesday': '45 mins cycling',
            'Wednesday': 'Rest day',
            'Thursday': '30 mins walking',
            'Friday': '30 mins interval running',
            'Saturday': 'Rest day',
            'Sunday': '1 hour light jogging'
        }
    }
    return workout_plans.get(goal, {})

# Diet and Nutrition Recommendations
def get_diet_recommendations(goal):
    # Map fitness goals to diet suggestions
    diet_plans = {
        'lose weight': [
            "Eat a balanced diet with fewer calories. Focus on whole foods like vegetables, lean proteins, and whole grains.",
            "Avoid processed foods, sugary drinks, and refined carbs.",
            "Incorporate healthy fats from nuts, seeds, and avocados."
        ],
        'increase stamina': [
            "Eat a balanced diet rich in carbohydrates for energy (whole grains, fruits, vegetables).",
            "Protein is key for muscle recovery. Consider lean meats, beans, and legumes.",
            "Stay hydrated and consume enough vitamins and minerals to support muscle function."
        ],
        'maintain fitness': [
            "Maintain a balanced intake of carbs, protein, and healthy fats.",
            "Focus on high-fiber foods like fruits, vegetables, and whole grains.",
            "Limit your intake of processed snacks and sugar, and make sure to drink plenty of water."
        ]
    }
    return diet_plans.get(goal, [])

# Streamlit App
st.title("Cardiovascular Exercise and Nutrition Assistant")

# Collect user information for personalized recommendations
st.header("Personalized Workout and Diet Plan")

# Input fields for fitness goals and symptoms
goal = st.selectbox("What is your fitness goal?", ['lose weight', 'increase stamina', 'maintain fitness'])

# Generate workout plan based on goal
workout_plan = generate_workout_plan(goal)
st.subheader(f"Your Custom Workout Plan for the Week:")
for day, exercise in workout_plan.items():
    st.write(f"{day}: {exercise}")

# Provide diet recommendations based on user goal
diet_recommendations = get_diet_recommendations(goal)
st.subheader(f"Recommended Diet for {goal.capitalize()}:")
for recommendation in diet_recommendations:
    st.write(f"- {recommendation}")

# Virtual Trainer with Exercise Video Demonstrations
st.header("Exercise Demonstrations")

# Select exercise type
exercise = st.selectbox("Select an exercise to view the demo video", ['walking', 'cycling', 'swimming', 'running'])

# Get and display video demonstration
video_link = get_video_demo(exercise)
if video_link:
    st.video(video_link)

# Track progress (Example)
st.subheader("Track Your Progress")
progress = st.slider("Track your progress", min_value=0, max_value=100, step=5, value=0)
st.write(f"Your current progress: {progress}%")
