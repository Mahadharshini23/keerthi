import sqlite3

def create_db():
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()

    # Create tables if they do not exist
    c.execute('''CREATE TABLE IF NOT EXISTS hospitals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL
                 )''')

    c.execute('''CREATE TABLE IF NOT EXISTS doctors (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    hospital_id INTEGER,
                    FOREIGN KEY (hospital_id) REFERENCES hospitals(id)
                 )''')

    c.execute('''CREATE TABLE IF NOT EXISTS appointments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    doctor_id INTEGER,
                    appointment_date TEXT,
                    FOREIGN KEY (doctor_id) REFERENCES doctors(id)
                 )''')
    
    conn.commit()
    conn.close()

create_db()

import streamlit as st
import sqlite3

# Function to connect to the database
def connect_db():
    return sqlite3.connect('hospital.db')

# Function to fetch hospital names
def get_hospitals():
    conn = connect_db()
    c = conn.cursor()
    c.execute("SELECT * FROM hospitals")
    hospitals = c.fetchall()
    conn.close()
    return hospitals

# Function to fetch doctors for a specific hospital
def get_doctors(hospital_id):
    conn = connect_db()
    c = conn.cursor()
    c.execute("SELECT * FROM doctors WHERE hospital_id = ?", (hospital_id,))
    doctors = c.fetchall()
    conn.close()
    return doctors

# Function to add a hospital
def add_hospital(name):
    conn = connect_db()
    c = conn.cursor()
    c.execute("INSERT INTO hospitals (name) VALUES (?)", (name,))
    conn.commit()
    conn.close()

# Function to add a doctor
def add_doctor(name, hospital_id):
    conn = connect_db()
    c = conn.cursor()
    c.execute("INSERT INTO doctors (name, hospital_id) VALUES (?, ?)", (name, hospital_id))
    conn.commit()
    conn.close()

# Function to add an appointment
def add_appointment(doctor_id, appointment_date):
    conn = connect_db()
    c = conn.cursor()
    c.execute("INSERT INTO appointments (doctor_id, appointment_date) VALUES (?, ?)", (doctor_id, appointment_date))
    conn.commit()
    conn.close()

# Admin interface for adding data
def admin_interface():
    st.title("Admin Interface")
    
    # Add Hospital
    st.header("Add New Hospital")
    hospital_name = st.text_input("Hospital Name")
    if st.button("Add Hospital"):
        if hospital_name:
            add_hospital(hospital_name)
            st.success(f"Hospital '{hospital_name}' added successfully!")
        else:
            st.error("Please provide a hospital name")

    # Add Doctor
    st.header("Add New Doctor")
    hospitals = get_hospitals()
    hospital_choices = [f"{h[1]}" for h in hospitals]
    selected_hospital = st.selectbox("Choose Hospital", hospital_choices)
    
    if selected_hospital:
        hospital_id = [h[0] for h in hospitals if h[1] == selected_hospital][0]
        doctor_name = st.text_input("Doctor Name")
        if st.button("Add Doctor"):
            if doctor_name:
                add_doctor(doctor_name, hospital_id)
                st.success(f"Doctor '{doctor_name}' added to '{selected_hospital}' hospital!")
            else:
                st.error("Please provide a doctor name")

    # Add Appointment
    st.header("Add Appointment")
    doctors = get_doctors(hospital_id) if hospital_id else []
    doctor_choices = [f"{d[1]}" for d in doctors]
    selected_doctor = st.selectbox("Choose Doctor", doctor_choices)
    
    if selected_doctor:
        doctor_id = [d[0] for d in doctors if d[1] == selected_doctor][0]
        appointment_date = st.date_input("Appointment Date")
        if st.button("Add Appointment"):
            if appointment_date:
                add_appointment(doctor_id, str(appointment_date))
                st.success(f"Appointment added for '{selected_doctor}' on {appointment_date}")
            else:
                st.error("Please provide an appointment date")

# User interface to view data
def user_interface():
    st.title("User Interface")
    
    st.header("Hospitals and Doctors")
    hospitals = get_hospitals()
    for hospital in hospitals:
        st.subheader(f"Hospital: {hospital[1]}")
        
        doctors = get_doctors(hospital[0])
        for doctor in doctors:
            st.write(f"Doctor: {doctor[1]}")
            
            # List appointments for the doctor
            conn = connect_db()
            c = conn.cursor()
            c.execute("SELECT * FROM appointments WHERE doctor_id = ?", (doctor[0],))
            appointments = c.fetchall()
            conn.close()

            for appointment in appointments:
                st.write(f"Appointment Date: {appointment[2]}")

# Select interface
interface_type = st.sidebar.radio("Select Interface", ["Admin", "User"])

if interface_type == "Admin":
    admin_interface()
elif interface_type == "User":
    user_interface()
